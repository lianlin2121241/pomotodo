# angular-file-upload-bower

bower distribution of [angular-file-upload](https://github.com/danialfarid/angular-file-upload).
All issues and pull request must be sumbitted to [angular-file-upload](https://github.com/danialfarid/angular-file-upload)

